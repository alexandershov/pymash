# function has `test`, so it counts as zero functions :)
def test_something():
    assert True
