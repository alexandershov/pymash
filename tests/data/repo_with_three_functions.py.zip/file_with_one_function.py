def zzz():    
    time.sleep(1)
